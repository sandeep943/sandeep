package com.niit.sportsgear1.dao;

import com.niit.sportsgear1.Model.SignupModel;

public interface UserDAO {

	public void insertSignupModel(SignupModel u);

	public boolean isValidUser(String un, String pd);
	public boolean isadmin(String u, String d);
}
