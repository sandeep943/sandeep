package com.niit.sportsgear1.dao;
import com.niit.sportsgear1.Model.*;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class UserDAOimpl implements UserDAO{
	
@Autowired
private SessionFactory sessionFactory;
    @Transactional
	public void insertSignupModel(SignupModel u)
	{
		Session s=this.sessionFactory.openSession();
		Transaction t=s.beginTransaction();
		s.save(u);
		t.commit();
	}
    @Transactional
	public boolean isValidUser(String un, String pd){
		System.out.println("UserDAOImpl - isValidUser() started");
		String hql = "from SignupModel where UserName= '" + un + "' and " + " Password ='" + pd + "'";
		//Query query = sessionFactory.getCurrentSession().createQuery(hql);
		Query query = sessionFactory.openSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<SignupModel> list = (List<SignupModel>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return true;
		}
		System.out.println("isValidUser() ended");
		return false;
	}
		
    @Transactional
   	public boolean isadmin(String u, String d){
   		System.out.println("UserDAOImpl - isValidUser() started");
   		String hql = "from SignupModel where UserName= '" + u + "' and " + " Password ='" + d + "' and isadmin='true'";
   		//Query query = sessionFactory.getCurrentSession().createQuery(hql);
   		Query query = sessionFactory.openSession().createQuery(hql);
   		System.out.println(hql);
   		@SuppressWarnings("unchecked")
   		List<SignupModel> list = (List<SignupModel>) query.list();
   		
   		if (list != null && !list.isEmpty()) {
   			return true;
   		}
   		System.out.println("isValidUser() ended");
   		return false;
   	}
   	
	
	
}

