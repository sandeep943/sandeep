package com.niit.sportsgear1.service;

import java.util.List;

import com.niit.sportsgear1.Model.ProductModel;
import com.niit.sportsgear1.Model.SupplierModel;

public interface ProductService {
	public void insertProductModel(ProductModel u);
	List<ProductModel> getProductList();
	void remove(Integer pid);
	void update(ProductModel p);


}
