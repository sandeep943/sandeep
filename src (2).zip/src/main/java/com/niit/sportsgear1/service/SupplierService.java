package com.niit.sportsgear1.service;

import java.util.List;

import com.niit.sportsgear1.Model.SupplierModel;

public interface SupplierService {
	public void insertSupplierModel(SupplierModel u);
	List<SupplierModel> getSupplierList();
	void remove(Integer sid);
	public void updateSupplier(SupplierModel p2);


}
