package com.niit.sportsgear1.service;

import com.niit.sportsgear1.Model.SignupModel;

public interface UserService{
		public void insertSignupModel(SignupModel u);

	}


